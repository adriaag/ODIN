<script lang="ts">
  import {
    fetchCategoricalColumns,
    fetchColumns,
    fetchNumericalColumns,
  } from "../visualizationComponents/CommonReqs";
  import Autocomplete from "@smui-extra/autocomplete";
  import { map } from "../ParametersConfigStore";
  import FormField from "@smui/form-field";
  import Checkbox from "@smui/checkbox";

  export let uriRef: string;
  export let valueType: string;
  export let slug: string;
  export let condition: string;
  export let dataset: string;

  let hasCondition = condition !== "";
  let conditionToggle = !hasCondition;

  enum ValueTypeEnum {
    CATEGORICAL = "CATEGORICAL",
    INCLUDED = "INCLUDED",
    NUMERICAL = "NUMERICAL",
    COLUMN = "COLUMN",
    COMPLETE = "COMPLETE",
  }
  
  function GetValueType(vType: String, condition: string) {
    let configDict: Record<string, boolean> = {};
    configDict[ValueTypeEnum.CATEGORICAL] = vType.includes("CATEGORICAL");
    configDict[ValueTypeEnum.INCLUDED] = condition.includes("INCLUDED");
    configDict[ValueTypeEnum.NUMERICAL] = vType.includes("NUMERICAL");
    configDict[ValueTypeEnum.COLUMN] = vType.includes("COLUMN");
    configDict[ValueTypeEnum.COMPLETE] = vType.includes("COMPLETE");
    console.log(configDict);
    return configDict;
  }

  let dataset_categorical_columns: { [key: string]: string } = {};
  let dataset_numerical_columns: { [key: string]: string } = {};
  let dataset_columns: { [key: string]: string } = {};

  let valueTypeEnum: Record<string, boolean> = {};
  async function loadData() {
    valueTypeEnum = GetValueType(valueType, condition);
    if (valueTypeEnum[ValueTypeEnum.CATEGORICAL]) {
      dataset_categorical_columns = await fetchCategoricalColumns(dataset);
    } else if (valueTypeEnum[ValueTypeEnum.NUMERICAL]) {
      dataset_numerical_columns = await fetchNumericalColumns(dataset);
    } else if (valueTypeEnum[ValueTypeEnum.COLUMN] || valueTypeEnum[ValueTypeEnum.COMPLETE]) {
      dataset_columns = await fetchColumns(dataset);
      if (valueTypeEnum[ValueTypeEnum.COMPLETE]) {
        dataset_columns["<RowID>"] = "";
      }
    }
  }
  $: console.log($map);
</script>

{#await loadData()}
  <p>loading components</p>
{:then value}
  {#if hasCondition}
    <FormField>
      <p>Has {slug}?</p>
      <Checkbox bind:checked={conditionToggle} />
    </FormField>
  {/if}

  {#if (hasCondition && conditionToggle) || !hasCondition}
    {#if valueTypeEnum[ValueTypeEnum.CATEGORICAL] && !valueTypeEnum[ValueTypeEnum.INCLUDED]}
      <Autocomplete
        options={Object.keys(dataset_categorical_columns)}
        textfield$variant="outlined"
        label={slug}
        bind:value={$map.categorical_column_choice}
      />
    {:else if valueTypeEnum[ValueTypeEnum.NUMERICAL] && !valueTypeEnum[ValueTypeEnum.INCLUDED]}
      <Autocomplete
        options={Object.keys(dataset_numerical_columns)}
        textfield$variant="outlined"
        bind:value={$map.numerical_column_choice}
        label={slug}
      />
    {:else if valueTypeEnum[ValueTypeEnum.COLUMN] || valueTypeEnum[ValueTypeEnum.COMPLETE]}
      {#if slug.includes(" Y ")}
        {#if valueTypeEnum[ValueTypeEnum.INCLUDED]}
          {#each Object.keys(dataset_columns) as option}
            {#if option !== $map.x_axis_column}
              <FormField>
                <p>{option}</p>
                <Checkbox bind:group={$map.y_axis_column_group} value={option} />
              </FormField>
            {/if}
          {/each}
        {:else}
          <Autocomplete
            options={Object.keys(dataset_columns)}
            textfield$variant="outlined"
            bind:value={$map.y_axis_column}
            label={slug}
          />
        {/if}
      {:else if valueTypeEnum[ValueTypeEnum.INCLUDED]}
        {#each Object.keys(dataset_columns) as option}
          {#if option !== $map.y_axis_column}
            <FormField>
              <p>{option}</p>
              <Checkbox bind:group={$map.x_axis_column_group} value={option} />
            </FormField>
          {/if}
        {/each}
      {:else}
        <Autocomplete
          options={Object.keys(dataset_columns)}
          textfield$variant="outlined"
          bind:value={$map.x_axis_column}
          label={slug}
        />
      {/if}
    {:else if valueTypeEnum[ValueTypeEnum.INCLUDED] && valueTypeEnum[ValueTypeEnum.NUMERICAL]}
      <div>
        {#each Object.keys(dataset_numerical_columns) as option}
          {#if option !== $map.numerical_column_choice}
            <FormField>
              <p>{option}</p>
              <Checkbox bind:group={$map.group_numerical_column_choices} value={option} />
            </FormField>
          {/if}
        {/each}
      </div>
    {:else if valueTypeEnum[ValueTypeEnum.INCLUDED] && valueTypeEnum[ValueTypeEnum.CATEGORICAL]}
      <div>
        {#each Object.keys(dataset_columns) as option}
          {#if option !== $map.x_axis_column}
            <FormField>
              <p>{option}</p>
              <Checkbox bind:group={$map.y_axis_column_group} value={option} />
            </FormField>
          {/if}
        {/each}
      </div>
    {/if}
  {/if}
{/await}
